




import 'package:bloc/bloc.dart';
import 'package:template/features/lab/auth/repo/repo.dart';


import 'login_state.dart';

class LoginCubit extends Cubit<LoginState> {

LoginCubit(this.authRepo) : super(LoginInitial());

  final AuthRepo authRepo;

  Future<void> login({
    required String password,
    required String email,
  }) async {
    emit(LoginLoading());

final response = await authRepo.login(
  email: email,
  password: password,
);
    response.fold(
      (failure) {
        print('❌ OTP Failure: ${failure.errMessage}');
        emit(LoginFailure(failure.errMessage));
      },
      (data) {
        print('✅ Success: $data');
        final message = data['message'] as String? ?? '';
        emit(LoginSuccess(message: message));
      },
    );
  }



}