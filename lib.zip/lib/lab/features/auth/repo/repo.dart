


import 'package:dartz/dartz.dart';
import 'package:template/core/errors/failures.dart';


abstract class AuthRepo {
  Future<Either<Failure, Map<String, dynamic>>> login({
    required String email,
    required String password,
  });
}
