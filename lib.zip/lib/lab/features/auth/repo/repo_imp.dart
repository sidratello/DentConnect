

import 'package:dartz/dartz.dart';
import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:template/core/api.dart';
import 'package:template/core/app_helper.dart';
import 'package:template/core/errors/failures.dart';


import 'repo.dart';

class AuthRepoImpl implements AuthRepo {
    final ApiService api;
  AuthRepoImpl(this.api);
  @override
  Future<Either<Failure, Map<String, dynamic>>> login({
    required String email,
    required String password,
  }) async {
    try {
      final data = await api.post(
        endPoint: 'login',
        body: {
          'Email': email,
          'password': password,
        },
      );

      final sp = await SharedPreferences.getInstance();
      final token = data['token'];

      if (token != null) {
        AppHelper.token = token;
        await sp.setString('token', token);
      }

      return right(data);
    } on DioException catch (e) {
      return left(ServerFailure.fromDioError(e));
    } catch (e) {
      return left(ServerFailure(e.toString()));
    }
  }
}