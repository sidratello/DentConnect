import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:template/core/app_helper.dart';
import 'package:template/core/app_router.dart';
import 'package:template/core/server_locater.dart';


void main() async {
  WidgetsFlutterBinding.ensureInitialized();


  setupServiceLocator();


  final sp = await SharedPreferences.getInstance();
  final token = sp.getString('token');

  if (token != null) {
    AppHelper.token = token;
  }

  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      routerConfig: AppRouter.router, 
      debugShowCheckedModeBanner: false,
    );
  }
}