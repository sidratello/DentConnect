


import 'package:dio/dio.dart';
import 'package:get_it/get_it.dart';
import 'package:template/core/api.dart';
import 'package:template/core/global_interceptor.dart';
import 'package:template/features/lab/auth/repo/repo.dart';
import 'package:template/features/lab/auth/repo/repo_imp.dart';

final getIt = GetIt.instance;

void setupServiceLocator() {

  final dio = Dio(
    BaseOptions(
      baseUrl: "https://192.168.137.173:10349/api/",
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      sendTimeout: const Duration(seconds: 10),
    ),
  )..interceptors.add(GlobalInterceptor());


  getIt.registerSingleton<Dio>(dio);

  getIt.registerSingleton<ApiService>(ApiService(getIt<Dio>()));

  getIt.registerSingleton<AuthRepo>(
    AuthRepoImpl(getIt<ApiService>()),
  );
}

