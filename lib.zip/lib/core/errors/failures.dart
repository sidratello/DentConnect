import 'dart:io';

import 'package:dio/dio.dart';

abstract class Failure {
  final String errMessage;

  const Failure(this.errMessage);
}

class ServerFailure extends Failure {
  ServerFailure(super.errMessage);

  factory ServerFailure.fromDioError(DioException dioError) {
    print('================ DioException ================');
    print('type: ${dioError.type}');

    switch (dioError.type) {
      case DioExceptionType.connectionTimeout:
        return ServerFailure('انتهت مهلة الاتصال بالخادم، يرجى المحاولة مرة أخرى.');

      case DioExceptionType.sendTimeout:
        return ServerFailure('انتهت مهلة إرسال الطلب، يرجى المحاولة مرة أخرى.');

      case DioExceptionType.receiveTimeout:
        return ServerFailure('انتهت مهلة استقبال البيانات من الخادم.');

      case DioExceptionType.badResponse:
        return ServerFailure.fromResponse(
          dioError.response?.statusCode,
          dioError.response?.data,
        );

      case DioExceptionType.cancel:
        return ServerFailure('تم إلغاء الطلب.');

      case DioExceptionType.unknown:
        if (dioError.error is SocketException) {
          return ServerFailure('لا يوجد اتصال بالإنترنت.');
        }
        return ServerFailure('حدث خطأ غير متوقع، يرجى المحاولة مرة أخرى.');

      default:
        return ServerFailure('حدث خطأ ما، يرجى المحاولة مرة أخرى.');
    }
  }

  factory ServerFailure.fromResponse(
    int? statusCode,
    dynamic response,
  ) {
    print("DEBUG RESPONSE: $response");

    if (statusCode == 400 || statusCode == 401 || statusCode == 403) {
      if (response is Map<String, dynamic>) {
        if (response["message"] != null) {
          final res = response["message"].toString();
          print("🔥 Backend Message: $res");
          return ServerFailure(res);
        }

        if (response["errors"] != null && response["errors"] is Map) {
          final errors = response["errors"] as Map;

          if (errors.isNotEmpty) {
            final firstEntry = errors.entries.first;
            final value = firstEntry.value;

            if (value is List && value.isNotEmpty) {
              final msg = value.last.toString();
              print("🔥 Backend Message: $msg");
              return ServerFailure(msg);
            } else {
              final msg = value.toString();
              print("🔥 Backend Message: $msg");
              return ServerFailure(msg);
            }
          }
        }
      }
    }

    if (statusCode == 404) {
      return ServerFailure('الطلب غير موجود، يرجى المحاولة لاحقًا.');
    } else if (statusCode == 500) {
      return ServerFailure('حدث خطأ في الخادم، يرجى المحاولة لاحقًا.');
    } else {
      return ServerFailure('حدث خطأ ما، يرجى المحاولة مرة أخرى.');
    }
  }
}