import 'dart:ui';

import 'package:template/core/app_colors.dart';
import 'package:template/core/app_font_size.dart';



class AppTextStyles {
  static  TextStyle senBold30WhiteStyle = TextStyle(
    fontFamily: "Sen",
    fontWeight: FontWeight.bold,
    fontSize: AppTextSizes.large30,
    color: AppColors.white,
  );
  static  TextStyle senRegular16WhiteStyle = TextStyle(
    fontFamily: "Sen",
    fontWeight: FontWeight.normal,
    fontSize: AppTextSizes.regular16,
    color: AppColors.white,
  );
    static  TextStyle senRegular14softGreyStyle = TextStyle(
    fontFamily: "Sen",
    fontWeight: FontWeight.normal,
    fontSize: AppTextSizes.medium14,
    color: AppColors.softGrey,
  );
    static  TextStyle senRegular13softGrey97Style = TextStyle(
    fontFamily: "Sen",
    fontWeight: FontWeight.normal,
    fontSize: AppTextSizes.small13,
    color: AppColors.softGrey97,
  );
  
}