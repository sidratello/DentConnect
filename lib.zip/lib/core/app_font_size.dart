class AppTextSizes {
  static const double small13 = 13.0;
  static const double medium14 = 14.0;
  static const double regular16 = 16.0;
  static const double large30 = 30.0;
}