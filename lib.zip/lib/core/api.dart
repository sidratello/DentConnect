
import 'package:dio/dio.dart';





class ApiService {
    final Dio _dio;

  ApiService(this._dio);
  static const _baseUrl = "https://192.168.137.173:10349/api/";






   Future<Map<String, dynamic>> get({required String endPoint}) async {

   print("📤 Sending Get request to: $_baseUrl$endPoint");

         var response = await _dio.get('$endPoint',
    
      );
return response.data;
      
  }

   Future<Map<String, dynamic>> post({
    required String endPoint,
    dynamic body,
  }) async {
        final formData = FormData.fromMap(body);
    try {
   print("📤 Sending POST request to: $_baseUrl$endPoint");
    print("📦 Body: $body");
      var response = await _dio.post(
       '$endPoint',
        data: formData,
     
      );
   print("............................... Response Status: ${response.statusCode}");
      print(".............................Response Data: ${response.data}");
return response.data;
} on DioException catch (e) {
      print("❌ API Error: $e");
      rethrow;
}
}

}