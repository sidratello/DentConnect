

import 'package:go_router/go_router.dart';

abstract class AppRouter {

  static const loginpage = '/loginpage';
  static const signuppage = '/';
  static const OTPpage = 'OTPpage';


   static final router = GoRouter(
  
     routes: [


  //     GoRoute(path: '/', builder: (context, state) => const SignUpscreen()),
  //     GoRoute(
  //       path: loginpage,
  //       builder: (context, state) => const loginscreen(),
  //     ),
  //     GoRoute(path: OTPpage, builder: (context, state) => const OTPscreen()),

    ],
  );
}
