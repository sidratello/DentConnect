import 'package:flutter/material.dart';


class AppColors {
  static const Color white = Color(0xFFFFFFFF);
  static const Color darkPrimary = Color(0xFF32343E);
  static const Color greyText = Color(0xFF646982);
  static const Color lightGrey = Color(0xFF78789F);
  static const Color softGrey = Color(0xFFA0A5BA);
    static const Color softGrey97 = Color(0xFF7E8A97);
}

